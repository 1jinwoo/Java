
public class SquareSum {

	public static void main(String[] args) {
				
		for (int i = 1; i <= 10; i++)	{
			System.out.println("(" + i + ") = " + squareSum(i));
		}
		System.out.println();
	}
	
	public static int squareSum(int size)	{
		
		int[] arr = new int[size];
		int sum = 0;	// will contain the summation result
		
		// TODO == implement by your code! ==
		// TODO assign each element of an array by (index)^2
		
		
		// TODO compute the "sum" of every element
		
		
		// TODO return the result rather than -1
		return -1;
		
	}

}

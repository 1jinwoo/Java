

public class Candidate {
	
	// complete this class!
	
	// TODO declare instance variables
	public int index;
	
	
	
	// TODO declare instance methods: introduce()	
	
	
	
	
	
}

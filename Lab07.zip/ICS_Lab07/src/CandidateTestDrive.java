

public class CandidateTestDrive {

	public static void main(String[] args) {
		
		// for example, candidates in 2017 19th South Korea Presidential Election   
		int[] indexes = {1, 2, 3, 4, 5};
		String[] names = {
				"Moon Jae-in",
				"Hong Joon-pyo",
				"Ahn Cheol-soo",
				"Yoo Seung-min",
				"Shim Sang-jeong"
				};
		
		// TODO instantiate at least two instances of Candidate class
		// - you can use one of above example, or set index/name by yourself
		
		// 1. declare instance variable, instantiate with "new" keyword
		
		
		// 2. set name and index using '=' (assignment operator) and '.' (dot operator)
		
		
		
		// 3. for test purpose, call introduce() method of an instance
		
		
		// do same things for other new instance
		
		
		
		
		
	}

}


public class P3 {

	public static void main(String[] args) {
		System.out.println(within8(7));		// => true 
		System.out.println(within8(13));	// => false
		System.out.println(within8(17));	// => true
	}
	
	public static boolean within8(int n)	{
		
		// TODO write your code after remove below return statement
		return false;
		
	}

}
